<!DOCTYPE HTML>
<html lang="PR">
<head>

  <title>barros Corretora</title>
  <meta charset="utf-8">
 
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  	<link rel="shortcut icon" type="image/png" href="../images/favicon.png"/>
	
 <script type="text/javascript" src="js/java.js"></script>
 
    
   
  <meta property="og:image" content="" />
  <meta property="og:description" content="Em nosso site, ..." />
  <meta property="og:url"content="/" />
  <meta property="og:title" content="Aluguel" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body >

<nav class="navbar navbar-default navbar-static-top  my-nav">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navtogg" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
				<div class="container"> 
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
								<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
								<a href="#" class="navbar-brand">barros Corretora</a> </div>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse mynavbar" id="bs-example-navbar-collapse-1">
								<ul class="nav navbar-nav ">
										<li><a href="#">Home</a></li>
										<li><a href="#">Services</a></li>
										
										<li><a href="#">Life</a></li>
										<li><a href="#">Contact Us</a></li>
								</ul>
						</div>
						<!-- /.navbar-collapse --> 
				</div>
				<!-- /.container --> 
		</nav>




 <div class="container"> <!-- container-->
 <a href=""></a>
 
 
<table style="width:34%; text-align:center; margin:auto; ">
  <tr>
    <th style=" font-size:20px; text-align:center;transition:all ease .3s;"><a href="#"><span id="imgtest">Destaques Venda</span></a></th>
    <th style=" font-size:20px; text-align:center"><a href="#"><span id="img">Destaques Aluguel</span></a></th> 
   
  </tr>
  <tr>
    <td class="angle_hiding"><i style=" font-size:48px; text-align:center;  margin-top:-17px; " class="fa fa-angle-down " ></i></td>
    <td class="angle_hiding"><i style="font-size:48px; text-align:center; " class=" " ></i></td> 
  
  </tr>
   
  </table>
  
  <script>
$(document).ready(function(){
    $("#imgtest").mouseover(function(){
        $(".angle_hiding").css("display", "table-cell");
    });
    $("#imgtest").mouseout(function(){
        $(".angle_hiding").css("display", "none");
    });
});



</script>


 
 
 <div class="col-md-2">
 </div>
 <div class="col-md-8">
        <div class="row" style="padding-top:35px">
            <div class="col-md-6"  >
			
                <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
				
                 <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
            </div>
			
			
            <div class="col-md-6">
			
                 <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques1.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
               <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques1.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
            </div>
        </div>
    </div>
   
</div>
</div> <!-- End of container-->

 <div class="container-fluid" style="padding-top:20px">
 <div class="row">
  
  <img  src="images/pampulha2.png" class="img-responsive" alt="Pampulha">
 
</div> 
</div>
</body>
</html>