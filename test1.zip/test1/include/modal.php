<div class="modal fade" id="myModal">
	<div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header" style="background:rgba(125,0,0,.7); height:30px; color:#ccc">
          <button  style="margin-top:-8px; font-size:18px; color:background:rgba(255,255,255,.9); background:rgba(255,255,255,.6); padding-left:3px; padding-right:3px" type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h5 class="modal-title" style="margin-top:-8px">Fale conosco</h5>
        </div>
        <div class="modal-body" style="padding-left:15%; padding-right:15%">
		<div class="form-group">
    		<label for="inputName">Nome</label>
    		<input class="  form-control" id="inputName" placeholder="Nome" type="email">
  		  </div>
		  
          <div class="form-group">
    		<label for="InputEmail">Email </label>
    		<input class="  form-control " id="inputEmail" placeholder=" Email" type="email">
  		  </div>
		  <div class="form-group">
		  	<label for="InputMesage">Messagen</label>
			    <textarea name="comments" id="comments" class="form-control" rows="3" ></textarea>
			
		  </div >
		  <div style="text-align:center">
		    <button style="background:rgba(125,0,0,.7); color:#ccc; border-radius: 25px;" type="submit" class="btn btn-default btn-sm ">Enviar messagen</button>
			</div>
        
        </div>
        <div class="modal-footer">
          <button><a href="#" data-dismiss="modal" class="btn btn-sm">fechar</a></button>
         
        </div>
      </div>
    </div>
</div>