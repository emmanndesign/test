<!DOCTYPE HTML>
<html lang="PR">
<head>

  <title>barros Corretora</title>
  <meta charset="utf-8">
 
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  	<link rel="shortcut icon" type="image/png" href="../images/favicon.png"/>
	
 <script type="text/javascript" src="js/java.js"></script>
 
    
   
  <meta property="og:image" content="" />
  <meta property="og:description" content="Em nosso site, ..." />
  <meta property="og:url"content="/" />
  <meta property="og:title" content="Aluguel" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body >


<nav class="navbar navbar-default navbar-static-top  my-nav">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navtogg" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
	  <a href="#" class="navbar-brand">barros Corretora</a> </div>
     
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div  class=" collapse navbar-collapse mynavbar " id="navtogg">
      <ul id="coloractive" class="nav navbar-nav  " data-hover="dropdown">
               
       <li><a href="#">Home</a></li></span>
		
		
        
		<li><a href="#">Empresa</a></li>
		 
		   <li><a href="#">anuncie seu movel</a></li>
		     <li class="dropdown">
                        <a data-toggle="dropdown"  href="#">area do cliente<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li class="dividerdrop"><a href="#">Trainers</a></li>
                            <li  class="dividerdrop"><a href="#">Zoos</a></li>
                            <li  class="dividerdrop"><a href="#">Hunters</a></li>
                            <li class="divider"></li>
                            <li  ><a href="#">Other Testimonials</a></li>
                        </ul>
          </li>
		    
			<li><a href="#myModal" data-toggle="modal" data-target="#myModal">contato</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>