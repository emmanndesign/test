
<?php
include("include/header.php");
include("include/modal.php");

?>







 <div class="container"> <!-- container-->

 
 
<table style="width:34%; text-align:center; margin:auto;  ">
  <tr>
    <th style=" font-size:20px; text-align:center;transition:all ease .3s;"><a href="#"><span id="imgtest">Destaques Venda</span></a></th>
    <th style=" font-size:20px; text-align:center"><a href="#"><span id="img">Destaques Aluguel</span></a></th> 
   
  </tr>
  <tr>
    <td class="angle_hiding"><i style=" font-size:48px; text-align:center;  margin-top:-17px; " class="fa fa-angle-down " ></i></td>
    <td class="angle_hiding"><i style="font-size:48px; text-align:center; " class=" " ></i></td> 
  
  </tr>
   
  </table>
  
  <script>
$(document).ready(function(){
    $("#imgtest").mouseover(function(){
        $(".angle_hiding").css("display", "table-cell");
    });
    $("#imgtest").mouseout(function(){
        $(".angle_hiding").css("display", "none");
    });
});



</script>


 
 
 <div class="col-md-2">
 </div>
 <div class="col-md-8">
        <div class="row" style="padding-top:35px">
            <div class="col-md-6"  >
			
                <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
				
                 <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
            </div>
			
			
            <div class="col-md-6">
			
                 <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques1.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
               <div class="media">
                    <div class="media-left">
                        <a href="#"><img class="media-object" src="images/destaques1.png"
                                         alt="Generic placeholder image" style="width:160px"></a>
                    </div>
                    <div class="media-body">
                        <span class="tag purple"><a href="#" >Castelo</a></span>

                        <h3 class="media-heading"><a  href="#" >Casa Geminada</a></h3>
                        <span style="font-size:10px " class="media-text"><i class="fa fa-arrows-alt fa_margin" ></i>250m<sup>2</sup> <i style="padding-left:30px" class="fa fa-tint fa_margin fa_margin-left" ></i>2 Banho(s)</span><br/>
						 <span style="font-size:10px" class="media-text"><i class="fa fa-bed fa_margin" ></i>2 Quartro(s)  <i class="fa fa-car fa_margin fa_margin-left" ></i>2 Vaga(s)</span>
                         <hr style="margin-top:10px; margin-bottom: 2px">
                        <span class="price" >R$10.000.000,00 <i style="margin-left:55px" class="fa fa-plus faplus" ></i></span>
                    </div>
                </div>
				
            </div>
        </div>
    </div>
   
</div>
</div> <!-- End of container-->

 <div class="container-fluid" style="padding-top:20px">
 <div class="row">
  
  <img  src="images/pampulha2.png" class="img-responsive" alt="Pampulha">
 
</div> 
</div>

<?php
include("include/footer.php");

?>
